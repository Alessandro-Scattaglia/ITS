<?php

class AutomobileDAO{
    private $connessione;
    public function __construct(){

    }

    public function getAutomobili(){
        $automobili = [];
        //fare una query al db
        //recuperare i risultati
        //trasofmrali in oggetto di tipo automobile
        //inseirrili nell'array $automobili
        //ritornare l'array di automobili con tutte le automobili

        return $automobili;
    }
    

}