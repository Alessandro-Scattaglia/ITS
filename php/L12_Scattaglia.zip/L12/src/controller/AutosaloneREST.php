<?php

class AutosaloneREST{
    private $service;

    
}