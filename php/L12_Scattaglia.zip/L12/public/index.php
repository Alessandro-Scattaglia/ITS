<?php
require '../src/config/config.php'; ?>

<?php
require '../src/config/router.php'; ?>

